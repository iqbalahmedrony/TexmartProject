<?php
// HTTP
define('HTTP_SERVER', 'http://localhost/texmartfashion/admin/');
define('HTTP_CATALOG', 'http://localhost/texmartfashion/');

// HTTPS
define('HTTPS_SERVER', 'http://localhost/texmartfashion/admin/');
define('HTTPS_CATALOG', 'http://localhost/texmartfashion/');

// DIR
define('DIR_APPLICATION', 'D:/xampp/htdocs/texmartfashion/admin/');
define('DIR_SYSTEM', 'D:/xampp/htdocs/texmartfashion/system/');
define('DIR_IMAGE', 'D:/xampp/htdocs/texmartfashion/image/');
define('DIR_LANGUAGE', 'D:/xampp/htdocs/texmartfashion/admin/language/');
define('DIR_TEMPLATE', 'D:/xampp/htdocs/texmartfashion/admin/view/template/');
define('DIR_CONFIG', 'D:/xampp/htdocs/texmartfashion/system/config/');
define('DIR_CACHE', 'D:/xampp/htdocs/texmartfashion/system/storage/cache/');
define('DIR_DOWNLOAD', 'D:/xampp/htdocs/texmartfashion/system/storage/download/');
define('DIR_LOGS', 'D:/xampp/htdocs/texmartfashion/system/storage/logs/');
define('DIR_MODIFICATION', 'D:/xampp/htdocs/texmartfashion/system/storage/modification/');
define('DIR_UPLOAD', 'D:/xampp/htdocs/texmartfashion/system/storage/upload/');
define('DIR_CATALOG', 'D:/xampp/htdocs/texmartfashion/catalog/');

// DB
define('DB_DRIVER', 'mysqli');
define('DB_HOSTNAME', 'localhost');
define('DB_USERNAME', 'root');
define('DB_PASSWORD', '');
define('DB_DATABASE', 'texmartfashiondb');
define('DB_PORT', '3306');
define('DB_PREFIX', 'oc_');
